package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.LahanEntity
import com.example.data.MasTaniRepository
import com.example.data.TransaksiEntity
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

data class LandSummary(
    val activeLahan: LahanEntity?,
    val hst: Int,
    val totalModal: Long,
    val modalMati: Long,
    val modalOperasional: Long,
    val totalPemasukan: Long,
    val labaBersih: Long,
    val totalPanenKg: Double,
    val modalPerTanaman: Double,
    val rataRataHasilPerTanaman: Double,
    val pendapatanPerTanaman: Double,
    val labaPerTanaman: Double,
    val modalPerKgPanen: Double,
    val labaPerKgPanen: Double
)

class MasTaniViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("mas_tani_prefs", Context.MODE_PRIVATE)

    private val _isDarkMode = MutableStateFlow(prefs.getBoolean("is_dark_mode", true))
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _fontScale = MutableStateFlow(prefs.getFloat("font_scale", 1.0f))
    val fontScale: StateFlow<Float> = _fontScale.asStateFlow()

    fun setDarkMode(enabled: Boolean) {
        _isDarkMode.value = enabled
        prefs.edit().putBoolean("is_dark_mode", enabled).apply()
    }

    fun setFontScale(scale: Float) {
        _fontScale.value = scale
        prefs.edit().putFloat("font_scale", scale).apply()
    }

    private val repository: MasTaniRepository

    val allLahan: StateFlow<List<LahanEntity>>

    private val _selectedLahanId = MutableStateFlow<Long?>(null)
    val selectedLahanId: StateFlow<Long?> = _selectedLahanId.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeTransactions: StateFlow<List<TransaksiEntity>>

    val landSummary: StateFlow<LandSummary>

    init {
        val db = AppDatabase.getDatabase(application)
        repository = MasTaniRepository(db.lahanDao(), db.transaksiDao())

        allLahan = repository.allLahan.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        activeTransactions = _selectedLahanId
            .flatMapLatest { id ->
                if (id != null) {
                    repository.getTransaksiForLahan(id)
                } else {
                    flowOf(emptyList())
                }
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = emptyList()
            )

        // Initialize repository safely and set default active land
        viewModelScope.launch {
            try {
                repository.checkAndPrepopulateDefaults()
            } catch (e: Exception) {
                e.printStackTrace()
            }
            allLahan.collect { list ->
                if (list.isNotEmpty() && _selectedLahanId.value == null) {
                    _selectedLahanId.value = list.first().id
                }
            }
        }

        // Combine active land and active transactions to produce real-time summary calculations
        landSummary = combine(allLahan, _selectedLahanId, activeTransactions) { lands: List<LahanEntity>, activeId: Long?, transactions: List<TransaksiEntity> ->
            val land = lands.find { it.id == activeId } ?: lands.firstOrNull()

            if (land == null) {
                LandSummary(
                    activeLahan = null,
                    hst = 0,
                    totalModal = 0,
                    modalMati = 0,
                    modalOperasional = 0,
                    totalPemasukan = 0,
                    labaBersih = 0,
                    totalPanenKg = 0.0,
                    modalPerTanaman = 0.0,
                    rataRataHasilPerTanaman = 0.0,
                    pendapatanPerTanaman = 0.0,
                    labaPerTanaman = 0.0,
                    modalPerKgPanen = 0.0,
                    labaPerKgPanen = 0.0
                )
            } else {
                val now = System.currentTimeMillis()
                val diffDays = ((now - land.tanggalTanamMillis) / (1000 * 60 * 60 * 24)).toInt()
                val hst = if (diffDays < 0) 0 else diffDays + 1

                var modalMatiSum = 0L
                var modalOperasionalSum = 0L
                var pemasukanSum = 0L
                var panenKgSum = 0.0

                for (tx in transactions) {
                    if (tx.jenis == "PENGELUARAN") {
                        if (tx.tipeModal == "MODAL_MATI") {
                            modalMatiSum += tx.nominal
                        } else {
                            modalOperasionalSum += tx.nominal
                        }
                    } else if (tx.jenis == "PEMASUKAN") {
                        pemasukanSum += tx.nominal
                        panenKgSum += tx.beratPanenKg
                    }
                }

                val totalModal = modalMatiSum + modalOperasionalSum
                val labaBersih = pemasukanSum - totalModal
                val count = land.jumlahTanaman

                val modalPerTanaman = if (count > 0) totalModal.toDouble() / count else 0.0
                val hasilPerTanaman = if (count > 0) panenKgSum / count else 0.0
                val pendapatanPerTanaman = if (count > 0) pemasukanSum.toDouble() / count else 0.0
                val labaPerTanaman = if (count > 0) labaBersih.toDouble() / count else 0.0

                val modalPerKg = if (panenKgSum > 0) totalModal.toDouble() / panenKgSum else 0.0
                val labaPerKg = if (panenKgSum > 0) labaBersih.toDouble() / panenKgSum else 0.0

                LandSummary(
                    activeLahan = land,
                    hst = hst,
                    totalModal = totalModal,
                    modalMati = modalMatiSum,
                    modalOperasional = modalOperasionalSum,
                    totalPemasukan = pemasukanSum,
                    labaBersih = labaBersih,
                    totalPanenKg = panenKgSum,
                    modalPerTanaman = modalPerTanaman,
                    rataRataHasilPerTanaman = hasilPerTanaman,
                    pendapatanPerTanaman = pendapatanPerTanaman,
                    labaPerTanaman = labaPerTanaman,
                    modalPerKgPanen = modalPerKg,
                    labaPerKgPanen = labaPerKg
                )
            }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = LandSummary(
                activeLahan = null, hst = 0, totalModal = 0, modalMati = 0, modalOperasional = 0,
                totalPemasukan = 0, labaBersih = 0, totalPanenKg = 0.0, modalPerTanaman = 0.0,
                rataRataHasilPerTanaman = 0.0, pendapatanPerTanaman = 0.0, labaPerTanaman = 0.0,
                modalPerKgPanen = 0.0, labaPerKgPanen = 0.0
            )
        )
    }

    fun selectLahan(lahanId: Long) {
        _selectedLahanId.value = lahanId
    }

    fun addLahan(nama: String, tanaman: String, jumlahTanaman: Int, tanggalTanamMillis: Long) {
        viewModelScope.launch {
            val list = allLahan.value
            val nextIndex = list.size + 1
            val id = repository.insertLahan(
                LahanEntity(
                    namaLahan = if (nama.isBlank()) "Lahan $nextIndex" else nama,
                    tanaman = if (tanaman.isBlank()) "Tanaman" else tanaman,
                    jumlahTanaman = if (jumlahTanaman <= 0) 1000 else jumlahTanaman,
                    tanggalTanamMillis = tanggalTanamMillis,
                    orderIndex = nextIndex
                )
            )
            _selectedLahanId.value = id
        }
    }

    fun updateLahan(lahan: LahanEntity) {
        viewModelScope.launch {
            repository.updateLahan(lahan)
        }
    }

    fun deleteLahan(lahan: LahanEntity) {
        viewModelScope.launch {
            repository.deleteLahan(lahan)
            val list = allLahan.value.filter { it.id != lahan.id }
            if (list.isNotEmpty()) {
                _selectedLahanId.value = list.first().id
            } else {
                _selectedLahanId.value = null
            }
        }
    }

    fun addTransaksi(
        lahanId: Long,
        jenis: String,
        tipeModal: String,
        kategori: String,
        namaBarang: String,
        nominal: Long,
        tanggalMillis: Long = System.currentTimeMillis(),
        beratPanenKg: Double = 0.0,
        hargaPerKg: Double = 0.0,
        pembeli: String = "",
        catatan: String = "",
        jumlahBarang: String = ""
    ) {
        viewModelScope.launch {
            repository.insertTransaksi(
                TransaksiEntity(
                    lahanId = lahanId,
                    tanggalMillis = tanggalMillis,
                    jenis = jenis,
                    tipeModal = tipeModal,
                    kategori = kategori,
                    namaBarang = if (namaBarang.isBlank()) kategori else namaBarang,
                    nominal = nominal,
                    beratPanenKg = beratPanenKg,
                    hargaPerKg = hargaPerKg,
                    pembeli = pembeli,
                    catatan = catatan,
                    jumlahBarang = jumlahBarang
                )
            )
        }
    }

    fun deleteTransaksi(id: Long) {
        viewModelScope.launch {
            repository.deleteTransaksiById(id)
        }
    }

    fun exportCsv(context: Context) {
        viewModelScope.launch {
            val transactions = activeTransactions.value
            val csvText = repository.exportToCsv(context, transactions)
            try {
                val file = java.io.File(context.cacheDir, "MasTani_Transaksi_Lahan_${_selectedLahanId.value ?: 1}.csv")
                file.writeText(csvText)

                val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                    type = "text/csv"
                    putExtra(android.content.Intent.EXTRA_SUBJECT, "Ekspor Transaksi Mas Tani")
                    val uri = androidx.core.content.FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        file
                    )
                    putExtra(android.content.Intent.EXTRA_STREAM, uri)
                    addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(android.content.Intent.createChooser(intent, "Bagikan / Simpan File CSV"))
            } catch (e: Exception) {
                Toast.makeText(context, "CSV diekspor (${transactions.size} baris)", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
