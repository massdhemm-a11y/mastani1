package com.example.ui.calculator

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.FarmGreenPrimary
import com.example.ui.theme.TextWhite
import java.text.NumberFormat
import java.util.Locale

object CurrencyUtils {
    fun formatRupiah(amount: Long): String {
        val formatter = NumberFormat.getNumberInstance(Locale("id", "ID"))
        return "Rp ${formatter.format(amount)}"
    }

    fun formatNumberOnly(amount: Long): String {
        val formatter = NumberFormat.getNumberInstance(Locale("id", "ID"))
        return formatter.format(amount)
    }

    fun formatDecimal(amount: Double): String {
        val formatter = NumberFormat.getNumberInstance(Locale("id", "ID"))
        formatter.minimumFractionDigits = 0
        formatter.maximumFractionDigits = 2
        return formatter.format(amount)
    }
}

@Composable
fun CalculatorKeypad(
    currentValueStr: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    onConfirm: (() -> Unit)? = null
) {
    val rows = listOf(
        listOf("7", "8", "9"),
        listOf("4", "5", "6"),
        listOf("1", "2", "3"),
        listOf("000", "0", "00")
    )

    fun handleKeyPress(key: String) {
        if (key == "C") {
            onValueChange("")
            return
        }
        val clean = currentValueStr.filter { it.isDigit() }
        if (clean.length >= 12) return // limit maximum input

        val updated = if (clean == "0") key else clean + key
        // Remove leading zeroes
        val trimmed = updated.dropWhile { it == '0' }
        onValueChange(if (trimmed.isEmpty()) "0" else trimmed)
    }

    fun handleBackspace() {
        val clean = currentValueStr.filter { it.isDigit() }
        if (clean.length <= 1) {
            onValueChange("0")
        } else {
            onValueChange(clean.substring(0, clean.length - 1))
        }
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp)),
        color = DarkSurface,
        shape = RoundedCornerShape(16.dp),
        tonalElevation = 4.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Header Row with Clear and Backspace
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                KeypadButton(
                    text = "Hapus Semua",
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    backgroundColor = Color(0xFF2C392F),
                    textColor = Color(0xFFFF8A80),
                    onClick = { onValueChange("0") }
                )
                KeypadButton(
                    text = "",
                    icon = {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Backspace,
                            contentDescription = "Hapus Angka",
                            tint = TextWhite
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    backgroundColor = Color(0xFF2C392F),
                    textColor = TextWhite,
                    onClick = { handleBackspace() }
                )
            }

            // Numeric Grid
            rows.forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    row.forEach { digit ->
                        KeypadButton(
                            text = digit,
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp)
                                .testTag("keypad_btn_$digit"),
                            backgroundColor = Color(0xFF203024),
                            textColor = TextWhite,
                            onClick = { handleKeyPress(digit) }
                        )
                    }
                }
            }

            if (onConfirm != null) {
                KeypadButton(
                    text = "Simpan Nominal",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("keypad_confirm_btn"),
                    backgroundColor = FarmGreenPrimary,
                    textColor = Color.Black,
                    fontWeight = FontWeight.Bold,
                    onClick = { onConfirm() }
                )
            }
        }
    }
}

@Composable
private fun KeypadButton(
    text: String,
    modifier: Modifier = Modifier,
    icon: (@Composable () -> Unit)? = null,
    backgroundColor: Color = Color(0xFF203024),
    textColor: Color = TextWhite,
    fontWeight: FontWeight = FontWeight.SemiBold,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(backgroundColor)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (icon != null) {
            icon()
        } else {
            Text(
                text = text,
                color = textColor,
                fontSize = 20.sp,
                fontWeight = fontWeight
            )
        }
    }
}
