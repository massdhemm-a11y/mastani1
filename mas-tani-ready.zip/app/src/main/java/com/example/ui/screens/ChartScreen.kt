package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TransaksiEntity
import com.example.ui.calculator.CurrencyUtils
import com.example.ui.theme.CapitalOrange
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DonutColor1
import com.example.ui.theme.DonutColor2
import com.example.ui.theme.DonutColor3
import com.example.ui.theme.DonutColor4
import com.example.ui.theme.DonutColor5
import com.example.ui.theme.DonutColor6
import com.example.ui.theme.DonutColor7
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.FarmGreenAccent
import com.example.ui.theme.FarmGreenPrimary
import com.example.ui.theme.IncomeBlue
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import java.util.Calendar
import java.util.Locale

data class CategorySlice(
    val category: String,
    val amount: Long,
    val percentage: Float,
    val color: Color
)

@Composable
fun ChartScreen(
    transactions: List<TransaksiEntity>,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) } // 0 = Pengeluaran, 1 = Pemasukan
    var selectedPeriod by remember { mutableStateOf("Tahun Ini") } // "Tahun Ini", "Tahun Lalu", "2026", "2025", "Semua"

    val periods = listOf("Tahun Ini", "2026", "2025", "Semua")

    // Filter transactions by period
    val calendar = Calendar.getInstance()
    val currentYear = calendar.get(Calendar.YEAR)

    val periodTransactions = transactions.filter { tx ->
        val txCal = Calendar.getInstance().apply { timeInMillis = tx.tanggalMillis }
        val txYear = txCal.get(Calendar.YEAR)

        when (selectedPeriod) {
            "Tahun Ini" -> txYear == currentYear
            "Tahun Lalu" -> txYear == (currentYear - 1)
            "2026" -> txYear == 2026
            "2025" -> txYear == 2025
            else -> true
        }
    }

    // Filter by type: Pengeluaran vs Pemasukan
    val targetType = if (selectedTab == 0) "PENGELUARAN" else "PEMASUKAN"
    val filteredTransactions = periodTransactions.filter { it.jenis == targetType }

    val totalAmount = filteredTransactions.sumOf { it.nominal }

    // Group by category
    val categoryMap = filteredTransactions.groupBy { it.kategori }
        .mapValues { entry -> entry.value.sumOf { it.nominal } }
        .toList()
        .sortedByDescending { it.second }

    val colorList = listOf(
        DonutColor1, DonutColor2, DonutColor3, DonutColor4, DonutColor5, DonutColor6, DonutColor7
    )

    val categorySlices = categoryMap.mapIndexed { index, (cat, amount) ->
        val pct = if (totalAmount > 0) (amount.toFloat() / totalAmount) * 100f else 0f
        CategorySlice(
            category = cat,
            amount = amount,
            percentage = pct,
            color = colorList[index % colorList.size]
        )
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .padding(bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Grafik Keuangan",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = TextWhite
        )

        // Tab Selector: Pengeluaran | Pemasukan
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = DarkSurface,
            contentColor = TextWhite,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = if (selectedTab == 0) ExpenseRed else ProfitGreen
                )
            }
        ) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }) {
                Text(
                    text = "Pengeluaran",
                    modifier = Modifier.padding(12.dp),
                    fontWeight = FontWeight.Bold,
                    color = if (selectedTab == 0) ExpenseRed else TextMuted
                )
            }
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }) {
                Text(
                    text = "Pemasukan",
                    modifier = Modifier.padding(12.dp),
                    fontWeight = FontWeight.Bold,
                    color = if (selectedTab == 1) ProfitGreen else TextMuted
                )
            }
        }

        // Period Pills
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            periods.forEach { period ->
                val isSelected = selectedPeriod == period
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedPeriod = period },
                    label = { Text(period, fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = FarmGreenPrimary,
                        selectedLabelColor = Color.Black,
                        containerColor = DarkSurface,
                        labelColor = TextWhite
                    )
                )
            }
        }

        // Donut Chart Container
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, DarkCardBorder, RoundedCornerShape(16.dp)),
            color = DarkSurface
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Proporsi ${if (selectedTab == 0) "Pengeluaran" else "Pemasukan"} ($selectedPeriod)",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMuted
                )

                if (categorySlices.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Belum ada transaksi di periode ini", color = TextMuted)
                    }
                } else {
                    Box(
                        modifier = Modifier.size(200.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        // Custom Donut Canvas
                        DonutCanvas(slices = categorySlices)

                        // Donut Center Content
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "Total",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                            Text(
                                text = "${CurrencyUtils.formatNumberOnly(totalAmount / 1000)}",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = TextWhite
                            )
                            Text(
                                text = "Ribu",
                                fontSize = 11.sp,
                                color = FarmGreenAccent,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Category Breakdown List below Donut Chart
        if (categorySlices.isNotEmpty()) {
            Text(
                text = "Rincian Kategori",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = TextWhite
            )

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                categorySlices.forEach { slice ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, DarkCardBorder, RoundedCornerShape(12.dp)),
                        color = DarkSurface
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(12.dp)
                                            .clip(CircleShape)
                                            .background(slice.color)
                                    )
                                    Text(
                                        text = slice.category,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextWhite
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text(
                                        text = CurrencyUtils.formatRupiah(slice.amount),
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextWhite
                                    )
                                    Text(
                                        text = "${String.format(Locale.US, "%.1f", slice.percentage)}%",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = slice.color
                                    )
                                }
                            }

                            // Progress Bar
                            LinearProgressIndicator(
                                progress = { slice.percentage / 100f },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = slice.color,
                                trackColor = DarkCardBorder
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DonutCanvas(
    slices: List<CategorySlice>,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val strokeWidth = 36.dp.toPx()
        val diameter = size.minDimension - strokeWidth
        val topLeft = Offset(strokeWidth / 2, strokeWidth / 2)
        val arcSize = Size(diameter, diameter)

        var startAngle = -90f

        slices.forEach { slice ->
            val sweepAngle = (slice.percentage / 100f) * 360f
            drawArc(
                color = slice.color,
                startAngle = startAngle,
                sweepAngle = sweepAngle - 2f, // slight gap
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
            )
            startAngle += sweepAngle
        }
    }
}
