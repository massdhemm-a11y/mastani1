package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val FarmGreenPrimary = Color(0xFF4CAF50)
val FarmGreenDark = Color(0xFF2E7D32)
val FarmGreenLight = Color(0xFF81C784)
val FarmGreenAccent = Color(0xFF66BB6A)

val DarkBackground = Color(0xFF0F1711)
val DarkSurface = Color(0xFF17241A)
val DarkCardBorder = Color(0xFF253B2B)

val LightBackground = Color(0xFFF4F7F4)
val LightSurface = Color(0xFFFFFFFF)
val LightCardBorder = Color(0xFFD8E2D9)

val TextWhite = Color(0xFFFFFFFF)
val TextMuted = Color(0xFFA1B3A4)
val TextMutedLight = Color(0xFF556B58)
val TextDark = Color(0xFF1B261D)

val ProfitGreen = Color(0xFF43A047)
val ExpenseRed = Color(0xFFE53935)
val IncomeBlue = Color(0xFF1E88E5)
val GoldYellow = Color(0xFFFBC02D)
val CapitalOrange = Color(0xFFFB8C00)

val DonutColor1 = Color(0xFF4CAF50)
val DonutColor2 = Color(0xFF29B6F6)
val DonutColor3 = Color(0xFFAB47BC)
val DonutColor4 = Color(0xFFFFA726)
val DonutColor5 = Color(0xFF26A69A)
val DonutColor6 = Color(0xFFEC407A)
val DonutColor7 = Color(0xFF78909C)

