package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density

private val MasTaniDarkColorScheme = darkColorScheme(
    primary = FarmGreenPrimary,
    onPrimary = TextDark,
    primaryContainer = FarmGreenDark,
    onPrimaryContainer = TextWhite,
    secondary = FarmGreenAccent,
    onSecondary = TextWhite,
    tertiary = GoldYellow,
    background = DarkBackground,
    onBackground = TextWhite,
    surface = DarkSurface,
    onSurface = TextWhite,
    surfaceVariant = DarkCardBorder,
    onSurfaceVariant = TextMuted,
    outline = DarkCardBorder
)

private val MasTaniLightColorScheme = lightColorScheme(
    primary = FarmGreenDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCEDC8),
    onPrimaryContainer = Color(0xFF1B5E20),
    secondary = FarmGreenPrimary,
    onSecondary = Color.White,
    tertiary = GoldYellow,
    background = LightBackground,
    onBackground = TextDark,
    surface = LightSurface,
    onSurface = TextDark,
    surfaceVariant = LightCardBorder,
    onSurfaceVariant = TextMutedLight,
    outline = LightCardBorder
)

@Composable
fun MasTaniTheme(
    isDarkMode: Boolean = true,
    fontScale: Float = 1.0f,
    content: @Composable () -> Unit
) {
    val colorScheme = if (isDarkMode) MasTaniDarkColorScheme else MasTaniLightColorScheme
    val currentDensity = LocalDensity.current
    val customDensity = Density(
        density = currentDensity.density,
        fontScale = currentDensity.fontScale * fontScale
    )

    CompositionLocalProvider(LocalDensity provides customDensity) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}

