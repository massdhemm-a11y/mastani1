package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Analytics
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.FarmGreenPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

sealed class NavTab(
    val route: String,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    object Dashboard : NavTab("dashboard", "Beranda", Icons.Filled.Home, Icons.Outlined.Home)
    object History : NavTab("history", "Transaksi", Icons.Filled.ReceiptLong, Icons.Outlined.ReceiptLong)
    object Add : NavTab("add", "Tambah", Icons.Filled.Add, Icons.Filled.Add)
    object Chart : NavTab("chart", "Grafik", Icons.Filled.Analytics, Icons.Outlined.Analytics)
    object Settings : NavTab("settings", "Pengaturan", Icons.Filled.Settings, Icons.Outlined.Settings)
}

@Composable
fun MasTaniBottomNavigation(
    currentRoute: String,
    onTabSelected: (String) -> Unit,
    onFabClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val items = listOf(
        NavTab.Dashboard,
        NavTab.History,
        NavTab.Add, // Placeholder for center FAB
        NavTab.Chart,
        NavTab.Settings
    )

    Box(modifier = modifier) {
        NavigationBar(
            containerColor = DarkSurface,
            contentColor = TextWhite,
            tonalElevation = 8.dp
        ) {
            items.forEachIndexed { index, tab ->
                if (index == 2) {
                    // Center FAB gap space
                    NavigationBarItem(
                        selected = false,
                        onClick = { onFabClick() },
                        icon = { Box(modifier = Modifier.size(24.dp)) },
                        label = { Text("Tambah", fontSize = 11.sp, color = FarmGreenPrimary) },
                        enabled = true
                    )
                } else {
                    val isSelected = currentRoute == tab.route
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { onTabSelected(tab.route) },
                        icon = {
                            Icon(
                                imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                contentDescription = tab.title,
                                tint = if (isSelected) FarmGreenPrimary else TextMuted
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) FarmGreenPrimary else TextMuted
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = DarkCardBorder
                        ),
                        modifier = Modifier.testTag("nav_tab_${tab.route}")
                    )
                }
            }
        }

        // Prominent Center FAB Button
        FloatingActionButton(
            onClick = { onFabClick() },
            shape = CircleShape,
            containerColor = FarmGreenPrimary,
            contentColor = Color.Black,
            elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 8.dp),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = (-18).dp)
                .size(56.dp)
                .testTag("center_fab_add")
        ) {
            Icon(
                imageVector = Icons.Filled.Add,
                contentDescription = "Tambah Transaksi",
                modifier = Modifier.size(32.dp)
            )
        }
    }
}
