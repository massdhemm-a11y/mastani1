package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.calculator.CalculatorKeypad
import com.example.ui.calculator.CurrencyUtils
import com.example.ui.theme.CapitalOrange
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.FarmGreenPrimary
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddTransactionScreen(
    lahanId: Long,
    lahanName: String,
    onSaveTransaction: (
        jenis: String,
        tipeModal: String,
        kategori: String,
        namaBarang: String,
        nominal: Long,
        tanggalMillis: Long,
        beratPanenKg: Double,
        hargaPerKg: Double,
        pembeli: String,
        catatan: String,
        jumlahBarang: String
    ) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(0) } // 0 = Pengeluaran, 1 = Pemasukan

    var dateMillis by remember { mutableStateOf(System.currentTimeMillis()) }
    val dateFormat = SimpleDateFormat("EEEE, d MMMM yyyy", Locale("id", "ID"))

    // Pengeluaran Categories
    val modalMatiCategories = listOf(
        "Mulsa", "Olah Lahan", "Ajir", "Alat Pertanian", "Selang", "Pompa", "Peralatan Lainnya"
    )
    val operasionalCategories = listOf(
        "Benih", "Pupuk", "Pestisida", "Tenaga Kerja", "BBM", "Air/Irigasi", "Transportasi", "Lainnya"
    )

    // Form state
    var selectedKategori by remember { mutableStateOf("Pupuk") }
    var tipeModal by remember { mutableStateOf("OPERASIONAL") }
    var namaBarang by remember { mutableStateOf("") }
    var jumlahBarang by remember { mutableStateOf("") }
    var catatan by remember { mutableStateOf("") }

    // Harvest specifics
    var beratPanenStr by remember { mutableStateOf("") }
    var hargaPerKgStr by remember { mutableStateOf("") }
    var pembeli by remember { mutableStateOf("") }

    // Keypad Raw Nominal String (e.g. "18000")
    var rawNominalStr by remember { mutableStateOf("0") }

    val computedNominal = rawNominalStr.toLongOrNull() ?: 0L

    // Date Picker Dialog
    fun openDatePicker() {
        val cal = Calendar.getInstance().apply { timeInMillis = dateMillis }
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val selectedCal = Calendar.getInstance().apply {
                    set(year, month, dayOfMonth)
                }
                dateMillis = selectedCal.timeInMillis
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    // Auto-calculate Total Harvest Sale if Harvest tab & user types weight x price
    fun recalculateHarvestTotal() {
        val berat = beratPanenStr.toDoubleOrNull() ?: 0.0
        val harga = hargaPerKgStr.toDoubleOrNull() ?: 0.0
        if (berat > 0 && harga > 0) {
            val total = (berat * harga).toLong()
            rawNominalStr = total.toString()
        }
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.Filled.ArrowBack,
                        contentDescription = "Kembali",
                        tint = TextWhite
                    )
                }
                Column {
                    Text(
                        text = if (selectedTab == 0) "Tambah Pengeluaran" else "Tambah Panen / Pemasukan",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                    Text(
                        text = "Lahan: $lahanName",
                        fontSize = 12.sp,
                        color = FarmGreenPrimary
                    )
                }
            }
        }

        // Tab Selector (Pengeluaran vs Pemasukan)
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = DarkSurface,
            contentColor = TextWhite,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = if (selectedTab == 0) ExpenseRed else ProfitGreen
                )
            }
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = {
                    selectedTab = 0
                    selectedKategori = "Pupuk"
                    tipeModal = "OPERASIONAL"
                },
                modifier = Modifier.testTag("tab_expense")
            ) {
                Text(
                    text = "Pengeluaran",
                    modifier = Modifier.padding(14.dp),
                    fontWeight = FontWeight.Bold,
                    color = if (selectedTab == 0) ExpenseRed else TextMuted
                )
            }
            Tab(
                selected = selectedTab == 1,
                onClick = {
                    selectedTab = 1
                    selectedKategori = "Hasil Panen"
                    tipeModal = "PEMASUKAN"
                },
                modifier = Modifier.testTag("tab_income")
            ) {
                Text(
                    text = "Pemasukan / Panen",
                    modifier = Modifier.padding(14.dp),
                    fontWeight = FontWeight.Bold,
                    color = if (selectedTab == 1) ProfitGreen else TextMuted
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Date Picker Banner
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, DarkCardBorder, RoundedCornerShape(12.dp))
                    .clickable { openDatePicker() },
                color = DarkSurface
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Tanggal Transaksi", fontSize = 11.sp, color = TextMuted)
                        Text(
                            text = dateFormat.format(Date(dateMillis)),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextWhite
                        )
                    }
                    Icon(
                        imageVector = Icons.Filled.CalendarToday,
                        contentDescription = "Ganti Tanggal",
                        tint = FarmGreenPrimary
                    )
                }
            }

            if (selectedTab == 0) {
                // Modal Type Selector: Modal Mati vs Operasional
                Text("Tipe Modal / Pengeluaran", fontSize = 13.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    FilterChip(
                        selected = tipeModal == "OPERASIONAL",
                        onClick = {
                            tipeModal = "OPERASIONAL"
                            selectedKategori = operasionalCategories.first()
                        },
                        label = { Text("Modal Operasional") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = FarmGreenPrimary,
                            selectedLabelColor = Color.Black,
                            containerColor = DarkSurface,
                            labelColor = TextWhite
                        ),
                        modifier = Modifier.weight(1f)
                    )

                    FilterChip(
                        selected = tipeModal == "MODAL_MATI",
                        onClick = {
                            tipeModal = "MODAL_MATI"
                            selectedKategori = modalMatiCategories.first()
                        },
                        label = { Text("Modal Mati") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CapitalOrange,
                            selectedLabelColor = Color.Black,
                            containerColor = DarkSurface,
                            labelColor = TextWhite
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }

                // Category Chips Grid
                Text("Pilih Kategori", fontSize = 13.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val catList = if (tipeModal == "MODAL_MATI") modalMatiCategories else operasionalCategories
                    catList.forEach { category ->
                        val isSelected = selectedKategori == category
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (isSelected) FarmGreenPrimary else DarkSurface)
                                .border(1.dp, if (isSelected) FarmGreenPrimary else DarkCardBorder, RoundedCornerShape(20.dp))
                                .clickable { selectedKategori = category }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = category,
                                color = if (isSelected) Color.Black else TextWhite,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }

                // Nama Barang & Jumlah
                OutlinedTextField(
                    value = namaBarang,
                    onValueChange = { namaBarang = it },
                    label = { Text("Nama Barang / Deskripsi (e.g. NPK Mutiara)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = FarmGreenPrimary,
                        unfocusedBorderColor = DarkCardBorder,
                        focusedLabelColor = FarmGreenPrimary,
                        unfocusedLabelColor = TextMuted,
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = jumlahBarang,
                    onValueChange = { jumlahBarang = it },
                    label = { Text("Jumlah & Satuan (Opsional, e.g. 2 Sak / 25 Kg)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = FarmGreenPrimary,
                        unfocusedBorderColor = DarkCardBorder,
                        focusedLabelColor = FarmGreenPrimary,
                        unfocusedLabelColor = TextMuted,
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

            } else {
                // Pemasukan / Panen Form
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = beratPanenStr,
                        onValueChange = {
                            beratPanenStr = it
                            recalculateHarvestTotal()
                        },
                        label = { Text("Berat Panen (Kg)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ProfitGreen,
                            unfocusedBorderColor = DarkCardBorder,
                            focusedLabelColor = ProfitGreen,
                            unfocusedLabelColor = TextMuted,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite
                        ),
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = hargaPerKgStr,
                        onValueChange = {
                            hargaPerKgStr = it
                            recalculateHarvestTotal()
                        },
                        label = { Text("Harga / Kg (Rp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ProfitGreen,
                            unfocusedBorderColor = DarkCardBorder,
                            focusedLabelColor = ProfitGreen,
                            unfocusedLabelColor = TextMuted,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = pembeli,
                    onValueChange = { pembeli = it },
                    label = { Text("Nama Pembeli / Tengkulak (Opsional)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ProfitGreen,
                        unfocusedBorderColor = DarkCardBorder,
                        focusedLabelColor = ProfitGreen,
                        unfocusedLabelColor = TextMuted,
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            OutlinedTextField(
                value = catatan,
                onValueChange = { catatan = it },
                label = { Text("Catatan Tambahan (Opsional)") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = FarmGreenPrimary,
                    unfocusedBorderColor = DarkCardBorder,
                    focusedLabelColor = FarmGreenPrimary,
                    unfocusedLabelColor = TextMuted,
                    focusedTextColor = TextWhite,
                    unfocusedTextColor = TextWhite
                ),
                modifier = Modifier.fillMaxWidth()
            )

            // Currency Field Display
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .border(
                        2.dp,
                        if (selectedTab == 0) ExpenseRed else ProfitGreen,
                        RoundedCornerShape(14.dp)
                    ),
                color = DarkSurface
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (selectedTab == 0) "TOTAL PENGELUARAN" else "TOTAL PENJUALAN",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted
                    )
                    Text(
                        text = CurrencyUtils.formatRupiah(computedNominal),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (selectedTab == 0) ExpenseRed else ProfitGreen
                    )
                }
            }

            // Embedded Calculator Keypad for Nominal Entry
            Text(
                text = "Keypad Nominal Uang",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextMuted
            )

            CalculatorKeypad(
                currentValueStr = rawNominalStr,
                onValueChange = { rawNominalStr = it }
            )

            // Submit Buttons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = onBack,
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = DarkSurface,
                        contentColor = TextMuted
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Batal", fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        val finalJenis = if (selectedTab == 0) "PENGELUARAN" else "PEMASUKAN"
                        val finalTipeModal = if (selectedTab == 0) tipeModal else "PEMASUKAN"
                        val finalKategori = if (selectedTab == 0) selectedKategori else "Hasil Panen"
                        val finalNamaBarang = if (selectedTab == 0) {
                            if (namaBarang.isBlank()) selectedKategori else namaBarang
                        } else {
                            if (catatan.isNotBlank()) "Panen - $catatan" else "Panen Hasil Tanam"
                        }

                        val beratKg = beratPanenStr.toDoubleOrNull() ?: 0.0
                        val hargaKg = hargaPerKgStr.toDoubleOrNull() ?: 0.0

                        onSaveTransaction(
                            finalJenis,
                            finalTipeModal,
                            finalKategori,
                            finalNamaBarang,
                            computedNominal,
                            dateMillis,
                            beratKg,
                            hargaKg,
                            pembeli,
                            catatan,
                            jumlahBarang
                        )
                        onBack()
                    },
                    modifier = Modifier
                        .weight(1.5f)
                        .height(52.dp)
                        .testTag("btn_save_transaction"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedTab == 0) ExpenseRed else ProfitGreen,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Simpan Transaksi", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
    }
}
