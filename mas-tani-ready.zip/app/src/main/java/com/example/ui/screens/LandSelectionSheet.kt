package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.LahanEntity
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.FarmGreenAccent
import com.example.ui.theme.FarmGreenPrimary
import com.example.ui.theme.GoldYellow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LandSelectionSheet(
    lands: List<LahanEntity>,
    selectedLandId: Long?,
    onSelectLand: (Long) -> Unit,
    onAddLand: (String, String, Int, Long) -> Unit,
    onUpdateLand: (LahanEntity) -> Unit,
    onDeleteLand: (LahanEntity) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var showAddDialog by remember { mutableStateOf(false) }
    var landToEdit by remember { mutableStateOf<LahanEntity?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = DarkBackground,
        contentColor = TextWhite
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Pilih Lahan",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                    Text(
                        text = "Kelola Data Keuangan per Lahan Secara Terpisah",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Tutup",
                        tint = TextMuted
                    )
                }
            }

            // List of Lands
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(lands, key = { it.id }) { land ->
                    val isSelected = land.id == selectedLandId
                    val now = System.currentTimeMillis()
                    val diffDays = ((now - land.tanggalTanamMillis) / (1000 * 60 * 60 * 24)).toInt()
                    val hst = if (diffDays < 0) 0 else diffDays + 1

                    LandCard(
                        land = land,
                        hst = hst,
                        isSelected = isSelected,
                        onClick = {
                            onSelectLand(land.id)
                            onDismiss()
                        },
                        onEdit = { landToEdit = land },
                        onDelete = { onDeleteLand(land) },
                        canDelete = lands.size > 1
                    )
                }
            }

            // Add Land Button
            Button(
                onClick = { showAddDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("btn_add_new_land"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = FarmGreenPrimary,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Filled.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Tambah Lahan Baru",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }

    if (showAddDialog) {
        LandFormDialog(
            title = "Tambah Lahan Baru",
            initialName = "Lahan ${lands.size + 1}",
            initialCrop = "Cabai",
            initialCount = 1000,
            initialDateMillis = System.currentTimeMillis(),
            onConfirm = { nama, tanaman, count, dateMillis ->
                onAddLand(nama, tanaman, count, dateMillis)
                showAddDialog = false
            },
            onDismiss = { showAddDialog = false }
        )
    }

    landToEdit?.let { land ->
        LandFormDialog(
            title = "Edit Data Lahan",
            initialName = land.namaLahan,
            initialCrop = land.tanaman,
            initialCount = land.jumlahTanaman,
            initialDateMillis = land.tanggalTanamMillis,
            onConfirm = { nama, tanaman, count, dateMillis ->
                onUpdateLand(land.copy(
                    namaLahan = nama,
                    tanaman = tanaman,
                    jumlahTanaman = count,
                    tanggalTanamMillis = dateMillis
                ))
                landToEdit = null
            },
            onDismiss = { landToEdit = null }
        )
    }
}

@Composable
private fun LandCard(
    land: LahanEntity,
    hst: Int,
    isSelected: Boolean,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    canDelete: Boolean
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) FarmGreenPrimary else DarkCardBorder,
                shape = RoundedCornerShape(14.dp)
            )
            .clickable { onClick() },
        color = DarkSurface,
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(if (isSelected) FarmGreenPrimary else DarkCardBorder),
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) {
                        Icon(
                            imageVector = Icons.Filled.CheckCircle,
                            contentDescription = "Selected",
                            tint = Color.Black,
                            modifier = Modifier.size(28.dp)
                        )
                    } else {
                        Text(
                            text = land.namaLahan.takeLast(1),
                            color = TextWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = land.namaLahan,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextWhite
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(GoldYellow.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "$hst HST",
                                color = GoldYellow,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Text(
                        text = "${land.tanaman} • ${land.jumlahTanaman} Tanaman",
                        fontSize = 13.sp,
                        color = FarmGreenAccent
                    )
                }
            }

            Row {
                IconButton(onClick = onEdit) {
                    Icon(
                        imageVector = Icons.Filled.Edit,
                        contentDescription = "Edit Lahan",
                        tint = TextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }
                if (canDelete) {
                    IconButton(onClick = onDelete) {
                        Icon(
                            imageVector = Icons.Filled.Delete,
                            contentDescription = "Hapus Lahan",
                            tint = ExpenseRed.copy(alpha = 0.8f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LandFormDialog(
    title: String,
    initialName: String,
    initialCrop: String,
    initialCount: Int,
    initialDateMillis: Long,
    onConfirm: (String, String, Int, Long) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(initialName) }
    var crop by remember { mutableStateOf(initialCrop) }
    var countStr by remember { mutableStateOf(initialCount.toString()) }
    var dateMillis by remember { mutableStateOf(initialDateMillis) }

    val dateFormat = SimpleDateFormat("dd MMMM yyyy", Locale("id", "ID"))

    fun openDatePicker() {
        val calendar = Calendar.getInstance().apply { timeInMillis = dateMillis }
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val selectedCal = Calendar.getInstance().apply {
                    set(year, month, dayOfMonth)
                }
                dateMillis = selectedCal.timeInMillis
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Text(text = title, color = TextWhite, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama Lahan") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = FarmGreenPrimary,
                        unfocusedBorderColor = DarkCardBorder,
                        focusedLabelColor = FarmGreenPrimary,
                        unfocusedLabelColor = TextMuted,
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = crop,
                    onValueChange = { crop = it },
                    label = { Text("Jenis Tanaman (e.g. Cabai Rawit Ori)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = FarmGreenPrimary,
                        unfocusedBorderColor = DarkCardBorder,
                        focusedLabelColor = FarmGreenPrimary,
                        unfocusedLabelColor = TextMuted,
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = countStr,
                    onValueChange = { countStr = it.filter { char -> char.isDigit() } },
                    label = { Text("Jumlah Tanaman (Batang)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = FarmGreenPrimary,
                        unfocusedBorderColor = DarkCardBorder,
                        focusedLabelColor = FarmGreenPrimary,
                        unfocusedLabelColor = TextMuted,
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .border(1.dp, DarkCardBorder, RoundedCornerShape(8.dp))
                        .clickable { openDatePicker() },
                    color = DarkBackground
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Tanggal Tanam", fontSize = 11.sp, color = TextMuted)
                            Text(
                                text = dateFormat.format(Date(dateMillis)),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextWhite
                            )
                        }
                        Icon(
                            imageVector = Icons.Filled.CalendarToday,
                            contentDescription = "Pilih Tanggal",
                            tint = FarmGreenPrimary
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cnt = countStr.toIntOrNull() ?: 1000
                    onConfirm(name, crop, cnt, dateMillis)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = FarmGreenPrimary,
                    contentColor = Color.Black
                )
            ) {
                Text("Simpan", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal", color = TextMuted)
            }
        }
    )
}
