package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Agriculture
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Grass
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.LocalFlorist
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Scale
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.calculator.CurrencyUtils
import com.example.ui.theme.CapitalOrange
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.FarmGreenAccent
import com.example.ui.theme.FarmGreenDark
import com.example.ui.theme.FarmGreenPrimary
import com.example.ui.theme.GoldYellow
import com.example.ui.theme.IncomeBlue
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.viewmodel.LandSummary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
    summary: LandSummary,
    allLandsCount: Int,
    onOpenLandSelector: () -> Unit,
    onAddExpenseClick: () -> Unit,
    onAddIncomeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val dateFormat = SimpleDateFormat("EEEE, d MMMM yyyy", Locale("id", "ID"))
    val land = summary.activeLahan

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .padding(bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Header & Land Switcher
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "MAS TANI",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = FarmGreenPrimary,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Catatan Keuangan & Pertanian",
                    fontSize = 12.sp,
                    color = TextMuted
                )
            }

            // Land Switch Chip
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, FarmGreenPrimary, RoundedCornerShape(20.dp))
                    .clickable { onOpenLandSelector() }
                    .testTag("land_selector_chip"),
                color = DarkSurface
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = land?.namaLahan ?: "Pilih Lahan",
                        fontWeight = FontWeight.Bold,
                        color = TextWhite,
                        fontSize = 14.sp
                    )
                    Icon(
                        imageVector = Icons.Filled.KeyboardArrowDown,
                        contentDescription = "Pilih Lahan",
                        tint = FarmGreenPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Active Crop Hero Card
        if (land != null) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, DarkCardBorder, RoundedCornerShape(16.dp)),
                color = DarkSurface
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(FarmGreenDark),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Grass,
                                    contentDescription = null,
                                    tint = FarmGreenPrimary,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = land.tanaman,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                                Text(
                                    text = "${land.namaLahan} • ${land.jumlahTanaman} Batang",
                                    fontSize = 13.sp,
                                    color = TextMuted
                                )
                            }
                        }

                        // HST Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(GoldYellow.copy(alpha = 0.2f))
                                .border(1.dp, GoldYellow, RoundedCornerShape(10.dp))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "${summary.hst} HST",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = GoldYellow
                                )
                                Text(
                                    text = "Hari Tanam",
                                    fontSize = 9.sp,
                                    color = GoldYellow.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CalendarToday,
                            contentDescription = null,
                            tint = TextMuted,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "Tanam: ${dateFormat.format(Date(land.tanggalTanamMillis))}",
                            fontSize = 12.sp,
                            color = TextMuted
                        )
                    }
                }
            }
        }

        // Clean Quick Action Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = onAddExpenseClick,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("btn_add_expense"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ExpenseRed.copy(alpha = 0.2f),
                    contentColor = ExpenseRed
                ),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ExpenseRed)
            ) {
                Icon(imageVector = Icons.Filled.ArrowDownward, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "Pengeluaran", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }

            Button(
                onClick = onAddIncomeClick,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("btn_add_harvest"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ProfitGreen.copy(alpha = 0.2f),
                    contentColor = ProfitGreen
                ),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ProfitGreen)
            ) {
                Icon(imageVector = Icons.Filled.ArrowUpward, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "+ Panen", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }

        // Net Profit Highlight Card
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(
                    1.dp,
                    if (summary.labaBersih >= 0) ProfitGreen else ExpenseRed,
                    RoundedCornerShape(16.dp)
                ),
            color = DarkSurface
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "LABA BERSIH",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted,
                        letterSpacing = 1.sp
                    )
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(
                                if (summary.labaBersih >= 0) ProfitGreen.copy(alpha = 0.2f)
                                else ExpenseRed.copy(alpha = 0.2f)
                            )
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (summary.labaBersih >= 0) "Untung" else "Rugi",
                            color = if (summary.labaBersih >= 0) ProfitGreen else ExpenseRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Text(
                    text = CurrencyUtils.formatRupiah(summary.labaBersih),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = if (summary.labaBersih >= 0) ProfitGreen else ExpenseRed
                )
            }
        }

        // Financial Summary Grid Cards
        Text(
            text = "Ringkasan Keuangan",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = TextWhite
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            MetricCard(
                title = "Total Pemasukan",
                value = CurrencyUtils.formatRupiah(summary.totalPemasukan),
                icon = Icons.Filled.Payments,
                iconColor = IncomeBlue,
                modifier = Modifier.weight(1f)
            )

            MetricCard(
                title = "Total Modal",
                value = CurrencyUtils.formatRupiah(summary.totalModal),
                icon = Icons.Filled.AccountBalanceWallet,
                iconColor = ExpenseRed,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            MetricCard(
                title = "Modal Mati",
                subtitle = "Mulsa, Olah Lahan, Pompa",
                value = CurrencyUtils.formatRupiah(summary.modalMati),
                icon = Icons.Filled.Build,
                iconColor = CapitalOrange,
                modifier = Modifier.weight(1f)
            )

            MetricCard(
                title = "Modal Operasional",
                subtitle = "Pupuk, Obat, Tenaga",
                value = CurrencyUtils.formatRupiah(summary.modalOperasional),
                icon = Icons.Filled.Agriculture,
                iconColor = FarmGreenPrimary,
                modifier = Modifier.weight(1f)
            )
        }

        // Production & Per-Plant Metrics
        Text(
            text = "Analisis Hasil & Per Tanaman",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = TextWhite
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            MetricCard(
                title = "Total Panen",
                value = "${CurrencyUtils.formatDecimal(summary.totalPanenKg)} Kg",
                icon = Icons.Filled.Scale,
                iconColor = GoldYellow,
                modifier = Modifier.weight(1f)
            )

            MetricCard(
                title = "Rata-rata / Tanaman",
                value = "${CurrencyUtils.formatDecimal(summary.rataRataHasilPerTanaman)} Kg/tanaman",
                icon = Icons.Filled.LocalFlorist,
                iconColor = FarmGreenAccent,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            MetricCard(
                title = "Modal / Tanaman",
                value = CurrencyUtils.formatRupiah(summary.modalPerTanaman.toLong()),
                icon = Icons.Filled.MonetizationOn,
                iconColor = CapitalOrange,
                modifier = Modifier.weight(1f)
            )

            MetricCard(
                title = "Pendapatan / Tanaman",
                value = CurrencyUtils.formatRupiah(summary.pendapatanPerTanaman.toLong()),
                icon = Icons.Filled.TrendingUp,
                iconColor = IncomeBlue,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            MetricCard(
                title = "Laba / Tanaman",
                value = CurrencyUtils.formatRupiah(summary.labaPerTanaman.toLong()),
                icon = Icons.Filled.Grass,
                iconColor = ProfitGreen,
                modifier = Modifier.weight(1f)
            )

            MetricCard(
                title = "Modal / Kg Panen",
                value = CurrencyUtils.formatRupiah(summary.modalPerKgPanen.toLong()),
                icon = Icons.Filled.Scale,
                iconColor = ExpenseRed,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    icon: ImageVector,
    iconColor: Color,
    modifier: Modifier = Modifier,
    subtitle: String? = null
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, DarkCardBorder, RoundedCornerShape(14.dp)),
        color = DarkSurface,
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(iconColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Text(
                    text = title,
                    fontSize = 12.sp,
                    color = TextMuted,
                    fontWeight = FontWeight.Medium
                )
            }

            Text(
                text = value,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = TextWhite
            )

            if (subtitle != null) {
                Text(
                    text = subtitle,
                    fontSize = 10.sp,
                    color = TextMuted.copy(alpha = 0.8f)
                )
            }
        }
    }
}
