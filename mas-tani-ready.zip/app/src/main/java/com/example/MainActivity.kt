package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.MasTaniBottomNavigation
import com.example.ui.components.NavTab
import com.example.ui.screens.AddTransactionScreen
import com.example.ui.screens.ChartScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.LandSelectionSheet
import com.example.ui.screens.SettingsReportScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.MasTaniTheme
import com.example.viewmodel.MasTaniViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: MasTaniViewModel = viewModel()
            val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
            val fontScale by viewModel.fontScale.collectAsStateWithLifecycle()

            MasTaniTheme(
                isDarkMode = isDarkMode,
                fontScale = fontScale
            ) {
                MasTaniApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MasTaniApp(viewModel: MasTaniViewModel = viewModel()) {
    var isSplashActive by remember { mutableStateOf(true) }
    var currentRoute by remember { mutableStateOf(NavTab.Dashboard.route) }
    var showLandSheet by remember { mutableStateOf(false) }

    val allLands by viewModel.allLahan.collectAsStateWithLifecycle()
    val selectedLandId by viewModel.selectedLahanId.collectAsStateWithLifecycle()
    val summary by viewModel.landSummary.collectAsStateWithLifecycle()
    val activeTransactions by viewModel.activeTransactions.collectAsStateWithLifecycle()
    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val fontScale by viewModel.fontScale.collectAsStateWithLifecycle()

    if (isSplashActive) {
        SplashScreen(
            onSplashFinished = { isSplashActive = false }
        )
    } else {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            bottomBar = {
                if (currentRoute != "add_transaction") {
                    MasTaniBottomNavigation(
                        currentRoute = currentRoute,
                        onTabSelected = { currentRoute = it },
                        onFabClick = { currentRoute = "add_transaction" }
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentRoute) {
                    NavTab.Dashboard.route -> {
                        DashboardScreen(
                            summary = summary,
                            allLandsCount = allLands.size,
                            onOpenLandSelector = { showLandSheet = true },
                            onAddExpenseClick = { currentRoute = "add_transaction" },
                            onAddIncomeClick = { currentRoute = "add_transaction" }
                        )
                    }

                    NavTab.History.route -> {
                        HistoryScreen(
                            transactions = activeTransactions,
                            onDeleteTransaction = { viewModel.deleteTransaksi(it) }
                        )
                    }

                    NavTab.Chart.route -> {
                        ChartScreen(
                            transactions = activeTransactions
                        )
                    }

                    NavTab.Settings.route -> {
                        SettingsReportScreen(
                            activeLahanName = summary.activeLahan?.namaLahan ?: "Semua Lahan",
                            isDarkMode = isDarkMode,
                            fontScale = fontScale,
                            onSetDarkMode = { viewModel.setDarkMode(it) },
                            onSetFontScale = { viewModel.setFontScale(it) },
                            onOpenLandSelector = { showLandSheet = true },
                            onExportCsv = { viewModel.exportCsv(it) },
                            onReplaySplash = { isSplashActive = true }
                        )
                    }

                    "add_transaction" -> {
                        val land = summary.activeLahan
                        AddTransactionScreen(
                            lahanId = land?.id ?: 1L,
                            lahanName = land?.namaLahan ?: "Lahan 1",
                            onSaveTransaction = { jenis, tipeModal, kategori, namaBarang, nominal, tanggalMillis, beratPanenKg, hargaPerKg, pembeli, catatan, jumlahBarang ->
                                viewModel.addTransaksi(
                                    lahanId = land?.id ?: 1L,
                                    jenis = jenis,
                                    tipeModal = tipeModal,
                                    kategori = kategori,
                                    namaBarang = namaBarang,
                                    nominal = nominal,
                                    tanggalMillis = tanggalMillis,
                                    beratPanenKg = beratPanenKg,
                                    hargaPerKg = hargaPerKg,
                                    pembeli = pembeli,
                                    catatan = catatan,
                                    jumlahBarang = jumlahBarang
                                )
                                currentRoute = NavTab.Dashboard.route
                            },
                            onBack = { currentRoute = NavTab.Dashboard.route }
                        )
                    }
                }

                // Land Selection Bottom Sheet Modal
                if (showLandSheet) {
                    LandSelectionSheet(
                        lands = allLands,
                        selectedLandId = selectedLandId,
                        onSelectLand = { viewModel.selectLahan(it) },
                        onAddLand = { name, crop, count, dateMillis ->
                            viewModel.addLahan(name, crop, count, dateMillis)
                        },
                        onUpdateLand = { viewModel.updateLahan(it) },
                        onDeleteLand = { viewModel.deleteLahan(it) },
                        onDismiss = { showLandSheet = false }
                    )
                }
            }
        }
    }
}
