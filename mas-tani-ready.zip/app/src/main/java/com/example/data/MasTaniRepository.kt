package com.example.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MasTaniRepository(
    private val lahanDao: LahanDao,
    private val transaksiDao: TransaksiDao
) {
    val allLahan: Flow<List<LahanEntity>> = lahanDao.getAllLahan()

    fun getLahanById(id: Long): Flow<LahanEntity?> {
        return lahanDao.getLahanById(id)
    }

    fun getTransaksiForLahan(lahanId: Long): Flow<List<TransaksiEntity>> {
        return transaksiDao.getTransaksiForLahan(lahanId)
    }

    fun getAllTransaksi(): Flow<List<TransaksiEntity>> {
        return transaksiDao.getAllTransaksi()
    }

    suspend fun insertLahan(lahan: LahanEntity): Long = withContext(Dispatchers.IO) {
        lahanDao.insertLahan(lahan)
    }

    suspend fun updateLahan(lahan: LahanEntity) = withContext(Dispatchers.IO) {
        lahanDao.updateLahan(lahan)
    }

    suspend fun deleteLahan(lahan: LahanEntity) = withContext(Dispatchers.IO) {
        transaksiDao.deleteAllForLahan(lahan.id)
        lahanDao.deleteLahan(lahan)
    }

    suspend fun insertTransaksi(transaksi: TransaksiEntity): Long = withContext(Dispatchers.IO) {
        transaksiDao.insertTransaksi(transaksi)
    }

    suspend fun updateTransaksi(transaksi: TransaksiEntity) = withContext(Dispatchers.IO) {
        transaksiDao.updateTransaksi(transaksi)
    }

    suspend fun deleteTransaksiById(id: Long) = withContext(Dispatchers.IO) {
        transaksiDao.deleteTransaksiById(id)
    }

    suspend fun checkAndPrepopulateDefaults() = withContext(Dispatchers.IO) {
        if (lahanDao.getLahanCount() == 0) {
            val now = System.currentTimeMillis()
            val dayMillis = 24 * 60 * 60 * 1000L

            // Lahan 1: Cabai Rawit Ori, planted 56 days ago (so today is 57 HST)
            val t1 = now - (56 * dayMillis)
            val id1 = lahanDao.insertLahan(
                LahanEntity(
                    namaLahan = "Lahan 1",
                    tanaman = "Cabai Rawit Ori",
                    jumlahTanaman = 1800,
                    tanggalTanamMillis = t1,
                    orderIndex = 1
                )
            )

            // Lahan 2: Cabai Keriting, planted 31 days ago (32 HST)
            val t2 = now - (31 * dayMillis)
            val id2 = lahanDao.insertLahan(
                LahanEntity(
                    namaLahan = "Lahan 2",
                    tanaman = "Cabai Keriting",
                    jumlahTanaman = 1200,
                    tanggalTanamMillis = t2,
                    orderIndex = 2
                )
            )

            // Lahan 3: Tomat, planted 14 days ago (15 HST)
            val t3 = now - (14 * dayMillis)
            val id3 = lahanDao.insertLahan(
                LahanEntity(
                    namaLahan = "Lahan 3",
                    tanaman = "Tomat",
                    jumlahTanaman = 900,
                    tanggalTanamMillis = t3,
                    orderIndex = 3
                )
            )

            // Sample Transactions for Lahan 1 matching reference values
            // Modal Mati
            transaksiDao.insertTransaksi(
                TransaksiEntity(
                    lahanId = id1,
                    tanggalMillis = t1 - (5 * dayMillis),
                    jenis = "PENGELUARAN",
                    tipeModal = "MODAL_MATI",
                    kategori = "Mulsa",
                    namaBarang = "Mulsa Hitam Perak",
                    nominal = 1850000L,
                    jumlahBarang = "2 Roll",
                    catatan = "Persiapan lahan"
                )
            )
            transaksiDao.insertTransaksi(
                TransaksiEntity(
                    lahanId = id1,
                    tanggalMillis = t1 - (4 * dayMillis),
                    jenis = "PENGELUARAN",
                    tipeModal = "MODAL_MATI",
                    kategori = "Ajir",
                    namaBarang = "Ajir Bambu 2 Meter",
                    nominal = 1200000L,
                    jumlahBarang = "1800 Btg",
                    catatan = "Pemasangan ajir"
                )
            )
            transaksiDao.insertTransaksi(
                TransaksiEntity(
                    lahanId = id1,
                    tanggalMillis = t1 - (3 * dayMillis),
                    jenis = "PENGELUARAN",
                    tipeModal = "MODAL_MATI",
                    kategori = "Pompa",
                    namaBarang = "Pompa Air Irigasi & Selang",
                    nominal = 2100000L,
                    jumlahBarang = "1 Unit",
                    catatan = "Sistem pengairan"
                )
            )

            // Operational Expenses Lahan 1
            transaksiDao.insertTransaksi(
                TransaksiEntity(
                    lahanId = id1,
                    tanggalMillis = t1,
                    jenis = "PENGELUARAN",
                    tipeModal = "OPERASIONAL",
                    kategori = "Benih",
                    namaBarang = "Benih Cabai Rawit Ori 212",
                    nominal = 950000L,
                    jumlahBarang = "10 Sachet"
                )
            )
            transaksiDao.insertTransaksi(
                TransaksiEntity(
                    lahanId = id1,
                    tanggalMillis = t1 + (10 * dayMillis),
                    jenis = "PENGELUARAN",
                    tipeModal = "OPERASIONAL",
                    kategori = "Pupuk",
                    namaBarang = "Pupuk NPK Mutiara 16-16-16",
                    nominal = 2850000L,
                    jumlahBarang = "2 Sak (100 Kg)"
                )
            )
            transaksiDao.insertTransaksi(
                TransaksiEntity(
                    lahanId = id1,
                    tanggalMillis = t1 + (20 * dayMillis),
                    jenis = "PENGELUARAN",
                    tipeModal = "OPERASIONAL",
                    kategori = "Pestisida",
                    namaBarang = "Insektisida & Fungisida Lengkap",
                    nominal = 1900000L,
                    jumlahBarang = "Paket Semprot"
                )
            )
            transaksiDao.insertTransaksi(
                TransaksiEntity(
                    lahanId = id1,
                    tanggalMillis = t1 + (30 * dayMillis),
                    jenis = "PENGELUARAN",
                    tipeModal = "OPERASIONAL",
                    kategori = "Tenaga Kerja",
                    namaBarang = "Upah Olah Lahan & Matun",
                    nominal = 1400000L,
                    jumlahBarang = "4 Orang"
                )
            )
            transaksiDao.insertTransaksi(
                TransaksiEntity(
                    lahanId = id1,
                    tanggalMillis = t1 + (40 * dayMillis),
                    jenis = "PENGELUARAN",
                    tipeModal = "OPERASIONAL",
                    kategori = "BBM",
                    namaBarang = "BBM Pompa Irigasi & Transport",
                    nominal = 600000L
                )
            )

            // Pemasukan / Panen Lahan 1
            transaksiDao.insertTransaksi(
                TransaksiEntity(
                    lahanId = id1,
                    tanggalMillis = t1 + (45 * dayMillis),
                    jenis = "PEMASUKAN",
                    tipeModal = "PEMASUKAN",
                    kategori = "Hasil Panen",
                    namaBarang = "Panen Perdana Cabai Rawit",
                    nominal = 8725000L,
                    beratPanenKg = 1100.0,
                    hargaPerKg = 25000.0,
                    pembeli = "Pak Budi",
                    catatan = "Panen ke-1"
                )
            )
            transaksiDao.insertTransaksi(
                TransaksiEntity(
                    lahanId = id1,
                    tanggalMillis = t1 + (52 * dayMillis),
                    jenis = "PEMASUKAN",
                    tipeModal = "PEMASUKAN",
                    kategori = "Hasil Panen",
                    namaBarang = "Panen Raya Cabai Rawit",
                    nominal = 10000000L,
                    beratPanenKg = 1250.0,
                    hargaPerKg = 24000.0,
                    pembeli = "Tengkulak Jaya",
                    catatan = "Panen ke-2"
                )
            )

            // Lahan 2 Sample Transactions
            transaksiDao.insertTransaksi(
                TransaksiEntity(
                    lahanId = id2,
                    tanggalMillis = t2 - (2 * dayMillis),
                    jenis = "PENGELUARAN",
                    tipeModal = "MODAL_MATI",
                    kategori = "Mulsa",
                    namaBarang = "Mulsa & Ajir Lahan 2",
                    nominal = 2500000L
                )
            )
            transaksiDao.insertTransaksi(
                TransaksiEntity(
                    lahanId = id2,
                    tanggalMillis = t2 + (5 * dayMillis),
                    jenis = "PENGELUARAN",
                    tipeModal = "OPERASIONAL",
                    kategori = "Pupuk",
                    namaBarang = "Pupuk Dasar NPK",
                    nominal = 3750000L
                )
            )
            transaksiDao.insertTransaksi(
                TransaksiEntity(
                    lahanId = id2,
                    tanggalMillis = t2 + (25 * dayMillis),
                    jenis = "PEMASUKAN",
                    tipeModal = "PEMASUKAN",
                    kategori = "Hasil Panen",
                    namaBarang = "Panen Cabai Keriting",
                    nominal = 9850000L,
                    beratPanenKg = 850.0,
                    hargaPerKg = 28000.0,
                    pembeli = "Lapak Pasar"
                )
            )

            // Lahan 3 Sample Transactions
            transaksiDao.insertTransaksi(
                TransaksiEntity(
                    lahanId = id3,
                    tanggalMillis = t3 - (2 * dayMillis),
                    jenis = "PENGELUARAN",
                    tipeModal = "MODAL_MATI",
                    kategori = "Alat Pertanian",
                    namaBarang = "Tiang & Tali Tomat",
                    nominal = 1150000L
                )
            )
            transaksiDao.insertTransaksi(
                TransaksiEntity(
                    lahanId = id3,
                    tanggalMillis = t3 + (3 * dayMillis),
                    jenis = "PENGELUARAN",
                    tipeModal = "OPERASIONAL",
                    kategori = "Benih",
                    namaBarang = "Benih Tomat Servo",
                    nominal = 2000000L
                )
            )
            transaksiDao.insertTransaksi(
                TransaksiEntity(
                    lahanId = id3,
                    tanggalMillis = t3 + (12 * dayMillis),
                    jenis = "PEMASUKAN",
                    tipeModal = "PEMASUKAN",
                    kategori = "Hasil Panen",
                    namaBarang = "Panen Tomat Awal",
                    nominal = 4200000L,
                    beratPanenKg = 300.0,
                    hargaPerKg = 14000.0
                )
            )
        }
    }

    suspend fun exportToCsv(context: Context, transactions: List<TransaksiEntity>): String {
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val sb = java.lang.StringBuilder()
        sb.append("ID,Tanggal,Jenis,Tipe Modal,Kategori,Nama Barang,Nominal,Berat Panen (kg),Harga/kg,Pembeli,Catatan\n")
        for (t in transactions) {
            sb.append("${t.id},")
            sb.append("\"${dateFormat.format(Date(t.tanggalMillis))}\",")
            sb.append("\"${t.jenis}\",")
            sb.append("\"${t.tipeModal}\",")
            sb.append("\"${t.kategori}\",")
            sb.append("\"${t.namaBarang.replace("\"", "\"\"")}\",")
            sb.append("${t.nominal},")
            sb.append("${t.beratPanenKg},")
            sb.append("${t.hargaPerKg},")
            sb.append("\"${t.pembeli.replace("\"", "\"\"")}\",")
            sb.append("\"${t.catatan.replace("\"", "\"\"")}\"\n")
        }
        return sb.toString()
    }
}
