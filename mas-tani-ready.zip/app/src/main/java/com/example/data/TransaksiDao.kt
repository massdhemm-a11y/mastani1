package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TransaksiDao {
    @Query("SELECT * FROM transaksi_table WHERE lahanId = :lahanId ORDER BY tanggalMillis DESC, id DESC")
    fun getTransaksiForLahan(lahanId: Long): Flow<List<TransaksiEntity>>

    @Query("SELECT * FROM transaksi_table ORDER BY tanggalMillis DESC, id DESC")
    fun getAllTransaksi(): Flow<List<TransaksiEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaksi(transaksi: TransaksiEntity): Long

    @Update
    suspend fun updateTransaksi(transaksi: TransaksiEntity)

    @Delete
    suspend fun deleteTransaksi(transaksi: TransaksiEntity)

    @Query("DELETE FROM transaksi_table WHERE id = :id")
    suspend fun deleteTransaksiById(id: Long)

    @Query("DELETE FROM transaksi_table WHERE lahanId = :lahanId")
    suspend fun deleteAllForLahan(lahanId: Long)

    @Query("DELETE FROM transaksi_table")
    suspend fun clearAllTransaksi()
}
