package com.example.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "transaksi_table",
    foreignKeys = [
        ForeignKey(
            entity = LahanEntity::class,
            parentColumns = ["id"],
            childColumns = ["lahanId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["lahanId"])]
)
data class TransaksiEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val lahanId: Long,
    val tanggalMillis: Long,
    val jenis: String, // "PENGELUARAN" or "PEMASUKAN"
    val tipeModal: String, // "MODAL_MATI", "OPERASIONAL", or "PEMASUKAN"
    val kategori: String,
    val namaBarang: String,
    val nominal: Long,
    val beratPanenKg: Double = 0.0,
    val hargaPerKg: Double = 0.0,
    val pembeli: String = "",
    val catatan: String = "",
    val jumlahBarang: String = ""
)
