package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "lahan_table")
data class LahanEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val namaLahan: String,
    val tanaman: String,
    val jumlahTanaman: Int,
    val tanggalTanamMillis: Long,
    val orderIndex: Int = 0
)
