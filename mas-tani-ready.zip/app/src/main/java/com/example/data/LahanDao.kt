package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface LahanDao {
    @Query("SELECT * FROM lahan_table ORDER BY orderIndex ASC, id ASC")
    fun getAllLahan(): Flow<List<LahanEntity>>

    @Query("SELECT * FROM lahan_table WHERE id = :id")
    fun getLahanById(id: Long): Flow<LahanEntity?>

    @Query("SELECT * FROM lahan_table WHERE id = :id")
    suspend fun getLahanByIdOneShot(id: Long): LahanEntity?

    @Query("SELECT COUNT(*) FROM lahan_table")
    suspend fun getLahanCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLahan(lahan: LahanEntity): Long

    @Update
    suspend fun updateLahan(lahan: LahanEntity)

    @Delete
    suspend fun deleteLahan(lahan: LahanEntity)
}
